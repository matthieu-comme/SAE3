Nom : COMME
Prenom : Matthieu
N Etud : 21702476

LE FICHIER "myparam.inc.php" SE TROUVE DANS LE DOSSIER inc

Lien video: https://youtu.be/ht1G_U4QLtk

pseudo: lutin1
mdp: MDP1
