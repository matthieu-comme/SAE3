<?php
define("MYHOST", '10.1.16.56/oracle2');
define("MYUSER", "matthieucomme");
define("MYPASS", "c21702476");
